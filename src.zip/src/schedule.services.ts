/* eslint-disable prettier/prettier */
import { Injectable } from "@nestjs/common/decorators";
import { InjectRepository } from "@nestjs/typeorm";
import { ScheduleRepository } from "./schedule.repo";
import { ScheduleEntity } from "./schedule.entity";

@Injectable()
export class ScheduleService{
    constructor(
        @InjectRepository(ScheduleRepository)
        private scheduleRepository: ScheduleRepository
    ) {}

    async findAll(): Promise<ScheduleEntity[]> {
        return this.scheduleRepository.find();
      }

      async findById(id: number): Promise<ScheduleEntity> {
        return this.scheduleRepository.findOne({where: {id}});
      }

}

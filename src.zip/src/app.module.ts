import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm/dist';
import { config } from './orm.config';
import { ScheduleEntity } from './schedule.entity';
import { ScheduleRepository } from './schedule.repo';
import { ScheduleService } from './schedule.services';
import { ScheduleController } from './schedule.controller';

@Module({
  imports: [
    TypeOrmModule.forRoot(config),
    TypeOrmModule.forFeature([ScheduleEntity, ScheduleRepository])
  ],
  controllers: [ScheduleController],
  providers: [ScheduleService],
})
export class AppModule {}

/* eslint-disable prettier/prettier */
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';


@Entity('Schedule')
export class ScheduleEntity {

    @PrimaryGeneratedColumn() id: number
    @Column() Description: string
    @Column() Date : Date
    @Column() completion: boolean

}


/* eslint-disable prettier/prettier */
import { Controller, Get } from "@nestjs/common";
import { ScheduleService } from "./schedule.services";
import { ScheduleEntity } from "./schedule.entity";

@Controller("Schedule")
export class ScheduleController{
    constructor(private scheduleService: ScheduleService) { }

    @Get()
    async findAll(): Promise<ScheduleEntity[]>{
        return this.scheduleService.findAll();
    }
}

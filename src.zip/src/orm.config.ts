/* eslint-disable prettier/prettier */
import { TypeOrmModuleOptions } from '@nestjs/typeorm';
export const config: TypeOrmModuleOptions = {
  type: 'postgres',
  username: 'postgres',
  password: 'The_Lojan2318',
  port: 5432,
  host: '127.0.0.1',
  database: 'Status',
  synchronize: false,
  entities: ['dist/**/*.entity{.ts,.js}'],
};
